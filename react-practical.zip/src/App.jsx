import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import './App.css';
import { FirstPage } from './components/firstPage/firstPage';
import { SecondPage } from './components/secondPage/secondPage';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Switch>
          <Route path="/" exact>
            <FirstPage />
          </Route>
          <Route path="/SecondPage" >
            <SecondPage />
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
