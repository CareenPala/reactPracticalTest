import React, { useState } from "react";
import Container from "../common/container/container";
import TopContent from "../common/topContent/topContent";
import './secondPage.css';

export const SecondPage = () => {
    const [inputList, setInputList] = useState({})

    const onClick = () => {
        setInputList((prevValue) => ({ ...prevValue, [Object.keys(prevValue).length + 1]: "" })
        )
    }

    const onChange = (event) => {
        setInputList((prevValue) => ({ ...prevValue, [event.target.id]: event.target.value }))
    }

    const inputElementsJsx = Object.keys(inputList).map((eachKey, index) =>
        <input key={index} id={eachKey} value={inputList[eachKey]} onChange={onChange} type="text" required />
    )

    return (
        <Container>
            <TopContent url="/" />
            <div className="output">
                <label>Dynamic Input Boxes</label>
                <div className="contentContainer">
                    <div>
                        {inputElementsJsx.length > 0 && <form className="inputBox">
                            {inputElementsJsx}
                            <button type="submit">Submit</button>
                        </form>}
                    </div>
                    <div><button id="add" onClick={onClick}>+</button></div>
                </div>
            </div>
        </Container >
    )
}