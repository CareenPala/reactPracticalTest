import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import visual_design from "../../assets/images/visual_design.png";
import discovery from "../../assets/svgs/discovery.svg";
import research from "../../assets/svgs/research.svg";
import wireframe from "../../assets/svgs/wireframe.svg";
import ui from "../../assets/svgs/ui.svg";
import user_exp_design from "../../assets/svgs/user_exp_design.svg";
import { saveDataApi } from "../../redux/action";
import Container from "../common/container/container";
import TopContent from "../common/topContent/topContent";
import "./firstPage.css";

const designButtons = [
    "User experience design",
    "Visual design",
    "Visual design",
    "Prototyping",
    "Content design",
    "Design systems"
]

export const FirstPage = () => {
    const dispatch = useDispatch();
    const data = useSelector((state) => state);

    useEffect(() => {
        console.log(data)
    }, [data]);

    useEffect(() => {
        setTimeout(() => {
            fetch('https://jsonplaceholder.typicode.com/users')
                .then((response) => {
                    return response.json();
                })
                .then((data) => {
                    dispatch(saveDataApi(data));
                })
                .catch(console.error());
        }, 3000)
    }, [dispatch]);

    return (
        <Container>
            <TopContent url="/secondPage"/>
            <div className="box2 flex">
                <div className="row3">
                    <img src={visual_design} id="pic2" alt="" className="image" />
                </div>
                <div className="row4">
                    <div className="text2">
                        <h2>More than visual design more than interactions.</h2>
                        <p>We take pride in our craft. Drawing in our deep expertise in design , our Product Design team cares for your users' experience over the entire customer journey, at every touchpoint with your company.</p>

                        <p>We shepherd your product through the entire design process.We aim to achieve your</p>

                        <p>We also collaborate with our Software Engineering team to ensure our designs are technically feasible within the constraints of the project.At the same time, we're watching for innovative new technologies that can make the expensive more seamless.</p>
                    </div>
                </div>
            </div>
            <div className="box3">
                <h2>Our Design Process</h2>
                <p>Every decision we make is informed and goal oriented with the user journey in mind.Designing with a</p>
            </div>
            <div className="box4">
                <div className="circle-dash flex flex-column-center align-center">
                    <div className="row5 flex flex-column-center absolute align-center">
                        <div className="svgs">
                            <img src={research} alt="" />
                        </div>
                        <h3 className="circle-icon-label">2. Research + project estimation</h3>
                    </div>
                    <div className="row6 flex flex-column-center absolute align-center">
                        <div className="svg1">
                            <img src={discovery} alt="" />
                        </div>
                        <h3 className="circle-icon-label">1. Discovery</h3>
                    </div>
                    <div className="text4">
                        <p>We sit down with you to discuss your business goals and your target audience.We determine the problems you are trying to solve, and together, we define the key features of the app/software your're trying to build.</p>
                    </div>
                    <div className="row7 flex flex-column-center absolute align-center">
                        <div className="svgs">
                            <img src={wireframe} alt="" />
                        </div>
                        <h3 className="circle-icon-label">3. UX wireframes</h3>
                    </div>
                    <div className="row8 flex flex-column-center absolute align-center">
                        <div className="svgs">
                            <img src={ui} alt="" />
                        </div>
                        <h3 className="circle-icon-label">4. UI application</h3>
                    </div>
                </div>
            </div>
            <div className="box5 flex flex-column-center align-center ">
                <h2>Product Design Services</h2>
                <div className="buttons flex align-center ">
                    {designButtons.map(eachButton =>
                        <button className="btn">{eachButton}</button>
                    )}
                </div>
            </div>
            <div className="box6 flex">
                <div className="row9 flex">
                    <div className="sub1">
                        <h2>User experience design</h2>
                        <p>Even after the Product Strategy phase we maintain a relentless focus on your business goal.  Our Product Design team ensures the product we deliver will solve your challenge while meeting your user's needs.</p>
                        <h3>TACTICS</h3>
                        <div className="one">
                            <div>
                                <p>Behavioral data analysis</p>
                                <p>Personalization architecture</p>
                            </div>
                            <div>
                                <p>Wireframe</p>
                                <p>User flow</p>
                            </div>
                        </div>
                    </div>
                    <div className="sub2">
                        <img src={user_exp_design} alt="" className="image" /></div>

                </div>
                <div className="row10 flex">
                    <div className="sub3">
                        <img src={visual_design} alt="" className="image" />
                    </div>
                    <div className="sub4">

                        <h2>Visual Design</h2>
                        <p>Yes we make your software product beautiful.We also make it easy to use,compelling and delightful.</p>
                        <h3>TACTICS</h3>

                        <div className="two">
                            <div>
                                <p>Design workshop</p>
                                <p>Custom iconography</p>
                                <p>Visual design concept</p>
                            </div>
                            <div>
                                <p>UI elements</p>
                                <p>Typography system</p>
                                <p>Style guide</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Container>
    )
}