import React from 'react';
import { Link } from "react-router-dom";
import product_design from "../../../assets/images/product_design.png";
import "./topContent.css";

const TopContent = (props) => {
  return (
      <div className="box1">
          <div className="row1">
              <div className="link">
                  <Link to={props.url}>Go Back</Link>
                  </div>
              <div className="text">
                  <h1>Product Design</h1>
                  <p>Our multifaceted apps are custom built and developed to support multiple platforms, including both android and iOS, making apps accessible for all</p>
              </div>
          </div>
          <div className="row2">
              <img src={product_design} id="pic1" alt="" />
          </div>
      </div>
  )
}

export default TopContent